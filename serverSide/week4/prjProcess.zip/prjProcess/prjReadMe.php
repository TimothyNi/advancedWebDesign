<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
	<!-- index.php - This is the Menu Page for Red Door Burgers
		Written by: Timothy Niccum
		Class: CSC 235 ServerSide Development
		Written:	10-1-16
		Revised:
	-->
	<title>Red Door Burgers Read Me.</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css" />
	
	</head>
	<body>
	<h1>Red Door Burgers</h1>
	<p>
		<a href="https://wireframe.cc/KPr1Cq" target="_blank">Wireframe for edit.php:</a><br />
		<img src="graphics/mockup.png" alt="mockup" style="width:50%;height:50%;"><br />
		<a href="https://wireframe.cc/R9SQ6L" target="_blank">Wireframe for index1.php:</a><br />
		<img src="graphics/mockup2.png" alt="mockup2" style="width:50%;height:50%;">
		
	<h3>Here is a link to the Presentation page:</h3>
   			<p><a href="http://timothyniccum.com/webAdminTim/Individual/presentation.php" target="_blank">Red Door Burgers Presentation Page</a></p>
	</body>
</html>